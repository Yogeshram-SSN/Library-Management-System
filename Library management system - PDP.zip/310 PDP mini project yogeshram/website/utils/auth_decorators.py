from flask import jsonify, request, session, redirect, url_for
from .json_file_handler import UserFileHandler
import functools


def auth_required(allowed_roles=["member"]):
    if allowed_roles is None:
        allowed_roles = []

    def decorator(f):
        @functools.wraps(f)
        def decorated_function(*args, **kwargs):
            try:
                user = session.get('user')

                if not user:
                    return redirect(url_for('auth.login'))

                username = user.get('username')

                if not username:
                    return redirect(url_for('auth.login'))

                # Fetch user data from storage
                users_data = UserFileHandler().read_json()
                user = users_data.get('users', {}).get(username)

                if not user:
                    return jsonify({"message": "Unauthorized: User not found"}), 401

                user_roles = user.get('roles', [])

                # Check if any of the user's roles are in the allowed roles
                if not any(role in allowed_roles for role in user_roles):
                    return jsonify({"message": "Forbidden: Insufficient privileges"}), 403

                # Proceed to the protected route
                return f(*args, **kwargs)
            except Exception as e:
                print("Error occurred:", e)
                return redirect('/')

        return decorated_function
    return decorator


def only_public():
    def decorator(f):
        @functools.wraps(f)
        def decorated_function(*args, **kwargs):
            try:

                user = session.get('user')
                
                if user:
                    return redirect('/dashboard')

                # Proceed to the protected route
                return f(*args, **kwargs)
            except Exception as e:
                print("Error occurred:", e)
                return redirect('/')

        return decorated_function
    return decorator
