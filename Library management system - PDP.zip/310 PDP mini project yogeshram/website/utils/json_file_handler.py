import json
from .singleton import Singleton


class UserFileHandler(Singleton):
    def __init__(self):
        self.file_path = 'website/storage/users.json'

    def read_json(self):
        try:
            """Read data from a JSON file."""
            with open(self.file_path, 'r') as file:
                return json.load(file)
        except FileNotFoundError:
            print('File not found: %s' % self.file_path)

    def write_json(self, data):
        """Write data to a JSON file."""
        with open(self.file_path, 'w') as file:
            json.dump(data, file, indent=4)


class BookFileHandler(Singleton):
    def __init__(self):
        self.file_path = 'website/storage/books.json'

    def read_json(self):
        try:
            """Read data from a JSON file."""
            with open(self.file_path, 'r') as file:
                return json.load(file)
        except FileNotFoundError:
            print('File not found: %s' % self.file_path)

    def write_json(self, data):
        """Write data to a JSON file."""
        with open(self.file_path, 'w') as file:
            json.dump(data, file, indent=4)
