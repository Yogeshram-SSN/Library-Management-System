import json


class Book:
    def __init__(self, id, title, author, genre, image_path, is_borrowed=False, borrowed_by=None):
        self.id = id
        self.title = title
        self.author = author
        self.genre = genre
        self.image_path = image_path
        self.is_borrowed = is_borrowed
        self.borrowed_by = borrowed_by

    def to_dict(self):
        """Convert the Book object into a dictionary."""
        return {
            "id": self.id,
            "title": self.title,
            "author": self.author,
            "genre": self.genre,
            "image_path": self.image_path,
            "is_borrowed": self.is_borrowed,
            "borrowed_by": self.borrowed_by,
        }
