class Admin:
    def __init__(self, name):
        self.name = name

    def view_books(self, library):
        return library.books

    def view_members(self, library):
        return library.members