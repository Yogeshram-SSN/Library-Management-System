from .. import Singleton
from .. import BookFileHandler
from .Book import Book
import datetime

class Library(Singleton):
    def __init__(self):
        self.file_handler = BookFileHandler()
        self.books = self.file_handler.read_json()
        self.user_records = {}

    def borrow_book(self, book_id, username):
        book = self.books.get(book_id)
        now = str(datetime.datetime.now())
        
        if book and not book['is_borrowed']:
            book['is_borrowed'] = True
            book['borrowed_by'] = username
            book['last_borrowed_date'] = now
            book['borrowed_date'] = now
            self.file_handler.write_json(self.books)
            return True
        return False

    def return_book(self, book_id):
        book = self.books.get(book_id)
        if book and book['is_borrowed']:
            book['is_borrowed'] = False
            book['last_borrowed_date'] = book['borrowed_date']
            book['borrowed_by'] = None
            book['borrowed_date'] = None
            self.file_handler.write_json(self.books)
            return True
        return False

    def get_all_books(self):
        book_list = []

        for book_id, book_info in self.books.items():
            book_info['id'] = book_id
            book_list.append(book_info)

        return book_list

    def add_book(self, book_dict):
        """Add a book to the library and save to the JSON file."""
        print(book_dict)
        book = Book(**book_dict)
        self.books[book.id] = book.to_dict()

        # Save the updated books data to the JSON file
        self.file_handler.write_json(self.books)

    def checkout_book(self, book_id, user):
        if book_id in self.books and self.books[book_id].is_borrowed:
            self.books[book_id].is_borrowed = False
            self.user_records[user.id] = self.user_records.get(
                user.id, []) + [book_id]
            return True
        return False
