from flask import Flask,current_app
import os
import json
from datetime import datetime


def create_json_modules():

    USER_AUTHENTICATION = {
        "name": 'users',
        "file_path": "users.json",
        "initial_storage": {"users": {}}
    }

    REQUIRED_MODULES = [USER_AUTHENTICATION]

    for module in REQUIRED_MODULES:
        try:
            name = module["name"]
            file_path = os.path.join("website/storage/", module["file_path"])
            initial_storage = module["initial_storage"]

            if os.path.exists(file_path):
                print(f"{name} module exists")
            else:
                with open(file_path, "w") as outfile:
                    json.dump(initial_storage, outfile, indent=4)
                    print(f"Initializing module {name}")
        except:
            print("[Error] MODULE INITIALIZATION")


def create_app():
    create_json_modules()
    app = Flask(__name__, static_url_path='/static')

    # Custom filter to format datetime

    @app.template_filter('datetimeformat')
    def datetimeformat(value, format='%d-%m-%Y %H:%M'):
        try:
            return datetime.strptime(value, '%Y-%m-%d %H:%M:%S.%f').strftime(format)
        except ValueError:
            return value  # or some default value like ''

    # Register the filter
    app.jinja_env.filters['datetimeformat'] = datetimeformat

    from .blueprints.views import views
    from .blueprints.auth import auth
    from .blueprints.books import books
    from .blueprints.dashboard import dashboard
    from .blueprints.admin import admin

    app.register_blueprint(views, url_prefix='/')
    app.register_blueprint(auth, url_prefix='/')
    app.register_blueprint(books, url_prefix='/books')
    app.register_blueprint(dashboard, url_prefix='/dashboard')
    app.register_blueprint(admin, url_prefix='/admin')

    return app
