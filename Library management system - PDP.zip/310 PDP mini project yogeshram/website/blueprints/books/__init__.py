from flask import Blueprint

# Create a Blueprint instance for the auth
books = Blueprint('books', __name__,
                  template_folder='templates',
                  static_url_path='/books', static_folder='../../storage/images')

from . import routes