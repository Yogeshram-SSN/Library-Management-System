import os
from flask import render_template, request, flash, current_app, redirect, url_for, session
import uuid
from . import books

from website.utils import auth_required
from website.utils.library import Library, Book

from flask import send_from_directory

library = Library()


@books.route('/image/<filename>')
def serve_image(filename):
    return send_from_directory(books.static_folder, filename)


@books.route('/', methods=['GET'])
@auth_required()
def catalogue():
    all_books = library.get_all_books()

    username = session.get('user').get('username')

    available_books = [book for book in all_books if book.get("borrowed_by") != username]

    return render_template('books.html', books=available_books, username=username)


@books.route('/<id>')
def individual_book(id=None):
    # Fetch the book

    # Return the book
    return render_template('book.html', id=id)


@books.route('/add', methods=['POST', 'GET'])
@auth_required(allowed_roles=['admin'])
def add():
    if request.method == 'POST':
        book_id = uuid.uuid4()

        title = request.form.get('title').lower()
        author = request.form.get('author').lower()
        genre = request.form.get('genre').lower()

        # Handle image file upload
        image = request.files['image']
        if image:
            # Generate a unique filename for the image
            image_filename = str(uuid.uuid4()) + \
                os.path.splitext(image.filename)[-1]

            image.save(os.path.join(
                current_app.root_path, 'storage', 'images', image_filename))
        else:
            image_filename = None

        book = Book(str(book_id), title, author,
                    genre, image_filename).to_dict()

        library.add_book(book)

        return redirect('/books/add')

    return render_template('create-book.html')


@books.route('/borrow/<book_id>', methods=['POST'])
@auth_required(allowed_roles=['member'])
def borrow(book_id):
    # Or get this from session after login
    username = request.form.get('username')

    if library.borrow_book(book_id, username):
        flash('Book borrowed successfully!')
    else:
        flash('This book is already borrowed.')
    return redirect(url_for('books.catalogue'))


@books.route('/return/<book_id>', methods=['POST'])
@auth_required(allowed_roles=['member'])
def return_book(book_id):
    if library.return_book(book_id):
        flash('Book returned successfully!')
    else:
        flash('This book was not borrowed.')
    return redirect(url_for('dashboard.home'))
