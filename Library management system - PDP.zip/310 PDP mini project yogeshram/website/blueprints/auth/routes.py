from flask import render_template, request, jsonify, redirect, flash, session,url_for
from . import auth
from website.utils import UserFileHandler
import os
from website.utils import only_public


@auth.route('/login', methods=['GET', 'POST'])
@only_public()
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')

        storage = UserFileHandler().read_json()
        users = storage.get("users", {})

        if username in users and users[username]["password"] == password:
            # User authenticated
            session['user'] = None
            session['user'] = {"username": username,
                               "roles": users[username]["roles"]}

            return redirect("/dashboard")
        else:
            # Authentication failed
            flash('Incorrect password, try again.', category='error')

    return render_template("login.html")


@auth.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')

        # Basic validation
        if not username or not password or not confirm_password:
            flash('Please fill out all fields.')
            return render_template("register.html")

        if password != confirm_password:
            flash('Passwords do not match.')
            return render_template("register.html")

        # Read existing users
        users_data = UserFileHandler().read_json()

        if username in users_data.get('users', {}):
            flash('Username already exists.')
            return render_template("register.html")


        # Add new user
        users_data['users'][username] = {
            "password": password,
            "roles": ["member"]
        }

        # Write back to the JSON file
        UserFileHandler().write_json(users_data)

        flash('Registration successful!')
        return redirect(url_for('dashboard.home'))

    return render_template("register.html")

@auth.route('/logout', methods=['POST'])
def logout():
    session['user'] = None
    return redirect('/')
