from flask import Blueprint

# Create a Blueprint instance for the auth
auth = Blueprint('auth', __name__,
                     template_folder='templates',
                     static_folder='static')

# Import the routes of the auth blueprint
from . import routes