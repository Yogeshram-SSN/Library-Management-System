from flask import Blueprint

# Create a Blueprint instance for the auth
dashboard = Blueprint('dashboard', __name__,
                      template_folder='templates',
                      static_folder='static')


from . import routes