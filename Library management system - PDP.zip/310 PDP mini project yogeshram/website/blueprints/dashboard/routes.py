from website.utils import auth_required
from . import dashboard
from flask import render_template, session

from website.utils.library import Library, Book

library = Library()


@dashboard.route('/', methods=['GET', 'POST'])
@auth_required(allowed_roles=["member", "admin"])
def home():
    user = session.get('user')

    all_books = library.get_all_books()

    username = session.get('user').get('username')

    borrowed_books = [book for book in all_books if book.get(
        "borrowed_by") == username]

    return render_template('dashboard.html', user=user, books=borrowed_books)
