from website.utils import auth_required
from . import admin
from flask import render_template, session

from website.utils.library import Library, Book

library = Library()


@admin.route('/', methods=['GET', 'POST'])
@auth_required(allowed_roles=["admin"])
def home():
    all_books = library.get_all_books()

    books = [book for book in all_books if book["is_borrowed"]]
    
    return render_template('admin_dashboard.html', books=books)
