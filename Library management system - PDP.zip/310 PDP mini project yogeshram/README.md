`flask --app server --debug run`

```
{
    "books": {
    "dba4a601-70fa-40f0-8ed1-d36c495fc57d": {
            "title": "alice in neverland",
            "author": "jeni conrad",
            "is_borrowed": false,
            "image_path": "69e53ff4-b825-4cd0-8d35-b6ab662d6bd8.png"
        }
    }
}
```

```
{
    "users": {
        "username": {
            "password": "123",
            "role": "admin"
        }
    }
}
```
